# Demo site for Gatsby Starter Elemental

Follow the folder structure to use the gatsby-starter-elemental.
